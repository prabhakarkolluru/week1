"""Field-level parsing helpers.
 
Every function here follows the same contract: it takes whatever ugly string the
CSV actually contained and returns either a clean typed value or None. None means
"absent or unparseable" — it never means zero, and it never raises. Deciding what
to *do* about a None is the caller's job, not ours.
 
That separation is deliberate. Parsing that raises forces the caller to wrap every
call in try/except, and the usual result is a bare `except:` that swallows real
bugs alongside bad data.
"""
 
from __future__ import annotations
 
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
 
 
# Values that different upstream systems use to mean "nothing here".
# Compared case-insensitively after stripping.
 
NULL_TOKENS: frozenset[str] = frozenset(
    {"", "na", "n/a", "null", "none", "-", "--", "nil", "nan", "?"}
)
 
 
# The date formats this source is known to emit. Order matters.
 
DATE_FORMATS: tuple[str, ...] = (
    "%Y-%m-%d",      # 2024-01-15
    "%d/%m/%Y",      # 15/01/2024
    "%d-%m-%Y",      # 15-01-2024
    "%b %d %Y",      # Jan 15 2024
    "%d %b %Y",      # 15 Jan 2024
    "%Y/%m/%d",      # 2024/01/15
)
 
 
# Currency symbols and separators we strip before parsing a number.
 
_AMOUNT_STRIP = re.compile(r"[₹$€£,\s]")
_TRAILING_MINUS = re.compile(r"^(?P<value>[\d.]+)-$")
_PARENTHESISED = re.compile(r"^\((?P<value>[\d.]+)\)$")
 
 
def is_null(raw: str | None) -> bool:
    """True when the raw field means 'no value'.
 
    Handles the different spellings of nothing that show up in this feed.
    """
    if raw is None:
        return True
 
    return raw.strip().lower() in NULL_TOKENS
 
 
def normalise_text(
    raw: str | None,
    *,
    title_case: bool = False,
) -> str | None:
    """Collapse whitespace and optionally title-case a text field.
 
    Returns None for null-ish input rather than an empty string, so that a
    missing region and a region literally named "" cannot be confused.
    """
    if is_null(raw):
        return None
 
    normalized_text = raw.strip()
 
    # Collapse internal whitespace.
    normalized_text = " ".join(normalized_text.split())
 
    if title_case:
        normalized_text = normalized_text.title()
 
    return normalized_text
 
 
def parse_date(raw: str | None) -> date | None:
    """Parse a date written in any of the formats this feed uses.
 
    Returns None when the value is missing or matches none of the known formats.
    A date that parses but is obviously wrong (year 1900, year 2999) is still
    returned — range checking is a validation concern, not a parsing one.
    """
    if is_null(raw):
        return None
 
    raw = raw.strip()
 
    for dt in DATE_FORMATS:
        try:
            return datetime.strptime(raw, dt).date()
        except ValueError:
            continue
 
    return None
 
 
def parse_amount(raw: str | None) -> Decimal | None:
    """Parse a monetary amount into a Decimal."""
    if is_null(raw):
        return None
 
    raw = raw.strip()
    negative = False
 
    parenthesised_match = _PARENTHESISED.fullmatch(raw)
 
    if parenthesised_match:
        negative = True
        raw = parenthesised_match.group("value")
 
    trailing_minus_match = _TRAILING_MINUS.fullmatch(raw)
 
    if trailing_minus_match:
        negative = True
        raw = trailing_minus_match.group("value")
 
    raw = _AMOUNT_STRIP.sub("", raw)
 
    try:
        amount = Decimal(raw)
 
        if negative:
            amount = -amount
 
        return amount
    except (InvalidOperation, ValueError):
        return None
 
 
def parse_int(raw: str | None) -> int | None:
    """Parse an integer, tolerating separators and a stray decimal .0 suffix."""
    if is_null(raw):
        return None
 
    raw = raw.strip()
 
    # Remove thousands separators.
    raw = raw.replace(",", "")
 
    # Handle values like 100.0, 100.00, etc.
    if re.fullmatch(r"[+-]?\d+\.0+", raw):
        raw = raw.split(".", 1)[0]
 
    try:
        return int(raw)
    except (ValueError, TypeError):
        return None